from setuptools import setup, find_packages

setup(
    name="xcrypt_hydra",
    version="0.1.0",
    author="Lloyd Raphael",
    author_email="balogunsulaiman37@proton.me",  # update this
    description="A perfected encryption system for AI security using quantum-inspired chaos, matrix cryptography, and digital signatures.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/QuantumXCryptDr/xcrypt_hydra",  # update if uploading to GitHub
    project_urls={
        "Source": "https://github.com/QuantumXCryptDr/xcrypt_hydra",  # update too
        "Bug Tracker": "https://github.com/yourusername/xcrypt_hydra/issues",
    },
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Security :: Cryptography",
        "License :: OSI Approved :: MIT License",  # or your actual license
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.8",
    install_requires=[
        "numpy",
        "sympy",
        "pycryptodome",
    ],
    include_package_data=True,
)
from setuptools import setup, find_packages

setup(
    name="xcrypt_hydra",
    version="0.1.0",
    description="A perfected encryption system for AI security using chaos, quantum-inspired logic, and digital signatures.",
    author="Dr Sulaiman",
    author_email="your_email@example.com",
    url="https://github.com/yourusername/xcrypt_hydra",  # Optional but great
    license="MIT",  # Or whatever license you prefer
    packages=find_packages(),
    install_requires=[
        "numpy",
        "sympy",
        "pycryptodome"
    ],
    entry_points={
        "console_scripts": [
            "xcrypt=xcrypt_hydra.__main__:main"
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7',
)

